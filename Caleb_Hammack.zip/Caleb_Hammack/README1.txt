Howdy,

The only issue with my program, to the best of my knowledge, is that if you draw, 
then clear the screen, then change the background color, any drawing that was on 
the right side of the screen is in black. I think somewthing was wrong with my unmarking,
but after testing and trying to figure it out I could not.

To the best of my knowledge, everything else works as intended.

I also did not implement any of the extra credit.

Caleb Hammack